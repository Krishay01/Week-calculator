const mybutton=document.getElementById("mybutton");
mybutton.addEventListener("click",function(){
  var dateinput=document.getElementById("input").value;
  var date1=new Date(dateinput);
  var oneJan=new Date(date1.getFullYear(),0,1);
  var numberOfdays=Math.floor((date1-oneJan)/(24*60*60*1000));
  var result=Math.ceil((date1.getDay()+1+numberOfdays)/7);
  return document.getElementById("result").innerHTML="week number of given day is:"+result;
})